<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "youremail@example.com";
    $subject = "Обратная связь";
    $message = $_POST['message'];
    $headers = "From: " . $_POST['email'];

    if (mail($to, $subject, $message, $headers)) {
        echo "Сообщение успешно отправлено";
    } else {
        echo "Ошибка при отправке сообщения";
    }
}
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <input type="email" name="email" placeholder="Ваш Email" required><br>
    <textarea name="message" placeholder="Ваше сообщение" required></textarea><br>
    <input type="submit" value="Отправить">
</form>

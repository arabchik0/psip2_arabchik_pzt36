<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "youremail@example.com";
    $subject = "Подписка на рассылку";
    $message = "Email подписчика: " . $_POST['email'];
    
    if (mail($to, $subject, $message)) {
        echo "Спасибо за подписку!";
    } else {
        echo "Ошибка при подписке";
    }
}
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <input type="email" name="email" placeholder="Ваш Email" required><br>
    <input type="submit" value="Подписаться">
</form>

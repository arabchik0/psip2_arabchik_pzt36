<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = "youremail@example.com";
    $subject = "Отправка анкеты";
    $message = "Имя: " . $_POST['name'] . "\n" .
               "Email: " . $_POST['email'] . "\n" .
               "Отзыв: " . $_POST['feedback'];

    if (mail($to, $subject, $message)) {
        echo "Анкета успешно отправлена";
    } else {
        echo "Ошибка при отправке анкеты";
    }
}
?>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <input type="text" name="name" placeholder="Ваше имя" required><br>
    <input type="email" name="email" placeholder="Ваш Email" required><br>
    <textarea name="feedback" placeholder="Ваш отзыв" required></textarea><br>
    <input type="submit" value="Отправить">
</form>

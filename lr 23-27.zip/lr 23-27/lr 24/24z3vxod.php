<?php
// Инициируем сессию
session_start();

// Пароль для входа в административную панель
$admin_password = "123";

// Проверяем, была ли отправлена форма входа
if(isset($_POST['password'])) {
    // Проверяем правильность введенного пароля
    if($_POST['password'] == $admin_password) {
        // Если пароль верный, устанавливаем переменную сессии для авторизации
        $_SESSION['admin'] = true;
        echo "Вы успешно вошли в административную панель.";
    } else {
        echo "Неверный пароль.";
    }
}

// Проверяем, авторизован ли пользователь
if(isset($_SESSION['admin']) && $_SESSION['admin'] === true) {
    // Показываем административную панель
    echo "Вы авторизованы как администратор.";
} else {
    // Показываем форму входа
    echo "<form method='post' action=''>
            Пароль: <input type='password' name='password'>
            <input type='submit' value='Войти'>
          </form>";
}
?>

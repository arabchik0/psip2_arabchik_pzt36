<?php
// Устанавливаем cookie
setcookie('username', 'user123', time() + (86400 * 30), "/"); // 86400 = 1 день

// Выводим информацию о установленной cookie
echo "Cookie установлена.<br>";

// Выводим значение cookie
if(isset($_COOKIE['username'])) {
    echo "Привет, " . $_COOKIE['username'] . "!";
} else {
    echo "Cookie 'username' не установлена.";
}

// Удаляем cookie
setcookie('username', '', time() - 3600, '/');

// Выводим информацию об удалении cookie
echo "<br>Cookie удалена.";
?>

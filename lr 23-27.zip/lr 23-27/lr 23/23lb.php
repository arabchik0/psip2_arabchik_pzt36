<!-- index.php -->

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вывод текущей даты и времени</title>
</head>
<body>

<?php
// Функция для получения даты с написанием дня недели на русском
function getRussianDayOfWeek($date) {
    $daysOfWeek = [
        'Mon' => 'понедельник',
        'Tue' => 'вторник',
        'Wed' => 'среда',
        'Thu' => 'четверг',
        'Fri' => 'пятница',
        'Sat' => 'суббота',
        'Sun' => 'воскресенье',
    ];

    $englishDayOfWeek = date('D', strtotime($date));
    
    return $daysOfWeek[$englishDayOfWeek];
}

// Вывод текущей даты в кратком формате (день. месяц. год)
echo "<p>Дата: " . date('j. m. Y') . "</p>";

// Вывод текущего времени
echo "<p>Время: " . date('H:i:s') . "</p>";

// Вывод текущего дня недели
$today = date('Y-m-d');
$dayOfWeek = getRussianDayOfWeek($today);
echo "<p>День недели: $dayOfWeek</p>";
?>

<form method="post" action="">
    <input type="submit" name="submit" value="Показать день недели">
</form>

<?php
// Обработка нажатия кнопки
if (isset($_POST['submit'])) {
    echo "<p>Сегодня " . getRussianDayOfWeek($today) . "</p>";
}
?>

</body>
</html>

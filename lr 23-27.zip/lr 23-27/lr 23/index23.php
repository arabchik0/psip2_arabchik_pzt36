<!-- index.php -->

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Работа с файлами в PHP</title>
</head>
<body>

<?php
// Задание 1: Файловая система - Получение информации о файле
$file = 'I:\OSPanel\domains\localhost\links.php';

echo "<h2>Файловая система</h2>";
echo "<p>file: $file</p>";
echo "<p>В последний раз редактировался: " . date("r", filemtime($file)) . "</p>";
echo "<p>В последний раз был открыт: " . date("r", fileatime($file)) . "</p>";
echo "<p>Размер: " . filesize($file) . " байт</p>";
?>

<?php
// Задание 2: Работа с папками
echo "<h2>Работа с папками</h2>";

$folder = opendir("../../domains/");
while (($entry = readdir($folder)) !== false) {
   echo "$entry <br />";
}
closedir($folder);
?>

<?php
// Задание 3.1: Чтение строки из текстового файла
echo "<h2>Чтение из текстового файла</h2>";

$fileHandle = fopen("1.txt", "r");
echo "<p>" . fgets($fileHandle) . "</p>";
fclose($fileHandle);
?>

<?php
// Задание 3.2: Чтение всех строк текстового файла
echo "<h2>Чтение всех строк из текстового файла</h2>";

$fileHandle = fopen("1.txt", "r");
while (!feof($fileHandle)) {
    echo fgets($fileHandle) . "<br />";
}
fclose($fileHandle);
?>

<?php
// Задание 4.1: Запись строки в текстовый файл
echo "<h2>Запись в текстовый файл</h2>";

$fileHandle = fopen("textfile.txt", "w");
fwrite($fileHandle, "PHP is fun!");
fclose($fileHandle);

$fileHandle = fopen("textfile.txt", "r");
echo "<p>" . fgets($fileHandle) . "</p>";
fclose($fileHandle);
?>

<?php
// Задание 4.2: Добавление блока текста в текстовый файл
echo "<h2>Добавление блока текста в текстовый файл</h2>";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fileHandle = fopen("textfile.txt", "a");
    fwrite($fileHandle, $_POST["textblock"]);
    fclose($fileHandle);
}

$fileHandle = fopen("textfile.txt", "r");
echo "<p>" . fgets($fileHandle) . "</p>";
fclose($fileHandle);
?>

</body>
</html>

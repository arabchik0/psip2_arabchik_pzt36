<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Форма</title>
</head>
<body>
    <form action="varik4php2.php" method="post">
        <label for="name">Ваше имя *</label>
        <input type="text" id="name" name="name" required><br><br>
        
        <label for="gender">Ваш пол *</label>
        <input type="radio" id="male" name="gender" value="male" required>
        <label for="male">М</label>
        <input type="radio" id="female" name="gender" value="female" required>
        <label for="female">Ж</label><br><br>
        
        <input type="checkbox" id="army" name="army">
        <label for="army">Служил в армии</label><br><br>
        
        <button type="submit">Отправить</button>
    </form>
</body>
</html>

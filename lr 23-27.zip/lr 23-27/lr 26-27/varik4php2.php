<?php
// Запуск сессии
session_start();

// Получение данных из формы, если они были отправлены
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $gender = $_POST['gender'];
    $army = isset($_POST['army']) ? 'Да' : 'Нет';
    
    // Сохранение данных в сессионные переменные
    $_SESSION['user_name'] = $name;
    $_SESSION['user_gender'] = $gender;
} else {
    echo "<p>Ошибка: данные не получены.</p>";
}

// Вывод имени и значения идентификатора сессии
echo "<h2>Данные о пользователе:</h2>";
echo "<p>Имя: " . $_SESSION['user_name'] . "</p>";
echo "<p>Пол: " . $_SESSION['user_gender'] . "</p>";
echo "<p>Значение идентификатора сессии: " . session_id() . "</p>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Обработка формы</title>
</head>
<body>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $gender = $_POST['gender'];
        $army = isset($_POST['army']) ? 'Да' : 'Нет';
        
        echo "<h2>Данные, полученные из формы:</h2>";
        echo "<p>Имя: $name</p>";
        echo "<p>Пол: $gender</p>";
        echo "<p>Служил в армии: $army</p>";
    } else {
        echo "<p>Ошибка: данные не получены.</p>";
    }
    ?>
</body>
</html>
